import { useEffect, useState } from "react";
import styles from "./styles.module.css";
import Navbar from './Navbar';
import MainArea from './MainArea';
import axios from "axios";

const Main = () => {
    const [data, setData] = useState([]);
    const [chartsData, setChartsData] = useState(null);
    const [user, setUser] = useState(null);

    const fetchData = async () => {
        try {
            const token = localStorage.getItem("token");

            const [userRes, graduatesRes, inflationsRes] = await Promise.all([
                axios.get("http://localhost:8080/api/user", {
                    headers: { Authorization: `Bearer ${token}` }
                }),
                axios.get("http://localhost:8080/api/graduates", {
                    headers: { Authorization: `Bearer ${token}` }
                }),
                axios.get("http://localhost:8080/api/inflations", {
                    headers: { Authorization: `Bearer ${token}` }
                }),
            ]);

            const user = userRes.data;
            setUser(user);

            // 🔀 Scal dane po roku
            const mergedData = graduatesRes.data.map(grad => {
                const inflation = inflationsRes.data.find(inf => inf.year === grad.year);
                return {
                    id: grad.year,
                    rok: grad.year,
                    inflacja: inflation?.rate ?? null,
                    absolwenci: grad.count
                };
            });

            setData(mergedData);
        } catch (err) {
            console.error("Błąd podczas pobierania danych:", err);
            window.location.href = "/login";
        }
    };


    const fetchCharts = async () => {
        try {
            const token = localStorage.getItem("token");
            const res = await axios.get("http://localhost:8080/api/charts", {
                headers: { Authorization: `Bearer ${token}` }
            });
            setChartsData(res.data);
        } catch (err) {
            console.error("Błąd podczas pobierania wykresów:", err);
        }

         // 🟡 MOCK obrazków wykresów
        // const mockCharts = [
        //     "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Inflation_graph.svg/800px-Inflation_graph.svg.png",
        //     "https://upload.wikimedia.org/wikipedia/commons/7/72/Line_chart_example.png"
        // ];
        // setChartsData(mockCharts);
    };

    useEffect(() => {
        fetchData();

        // 🟡 MOCK user + data (zamiast zapytań)
        // const mockUser = { name: "Jan Nowak", role: "User" }; // lub "User"
        // const mockData = [
        //     { id: 1, rok: 2003, inflacja: 1.2, absolwenci: 120000 },
        //     { id: 2, rok: 2004, inflacja: 2.1, absolwenci: 125000 },
        //     { id: 3, rok: 2005, inflacja: 1.8, absolwenci: 130000 },
        // ];
        // setUser(mockUser);
        // setData(mockData);
    }, []);

    const handleLogout = () => {
        localStorage.removeItem("token");
        window.location.href = "/login";

        console.log("Wylogowano");
    };

    if (!user) return <div>Ładowanie...</div>;

    return (
        <div className={styles.main_container}>
            <Navbar onLogout={handleLogout} username={user.name} />
            <MainArea
                data={data}
                setData={setData}
                role={user.role}
                chartsData={chartsData}
                fetchCharts={fetchCharts}
            />
        </div>
    );
};

export default Main;
