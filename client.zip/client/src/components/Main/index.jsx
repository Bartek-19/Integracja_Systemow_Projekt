import { useEffect, useState } from "react";
import styles from "./styles.module.css";
import Navbar from './Navbar';
import MainArea from './MainArea';
import axios from "axios";

const Main = () => {
    const [data, setData] = useState([]);
    const [chartsData, setChartsData] = useState(null);
    const [user, setUser] = useState(null);

    const fetchData = async () => {
        try {
            const token = localStorage.getItem("token");

            const [userRes, graduatesRes, inflationsRes] = await Promise.all([
                axios.get("http://localhost:8081/api/user", {
                    headers: { Authorization: `Bearer ${token}` }
                }),
                axios.get("http://localhost:8081/api/graduates", {
                    headers: { Authorization: `Bearer ${token}` }
                }),
                axios.get("http://localhost:8081/api/inflations", {
                    headers: { Authorization: `Bearer ${token}` }
                }),
            ]);

            const user = userRes.data;
            console.log("Użytkownik:", user);
            setUser(user);

            // Scalanie danych po roku
            const mergedData = graduatesRes.data.map(grad => {
                const inflation = inflationsRes.data.find(inf => inf.year === grad.year);
                return {
                    id: grad.year,
                    rok: grad.year,
                    inflacja: inflation?.rate ?? null,
                    absolwenci: grad.number
                };
            });

            setData(mergedData);
        } catch (err) {
            console.error("Błąd podczas pobierania danych:", err);
            window.location.href = "/login";
        }
    };

    const fetchCharts = async () => {
        try {
            const token = localStorage.getItem("token");
            const res = await axios.get("http://localhost:8081/api/charts", {
                headers: { Authorization: `Bearer ${token}` }
            });

            const files = res.data;

            // pobierz obrazki jako blob i zamień na URL - potrzebna autoryzacja (sam url wywołuje 403)
            const chartsUrls = await Promise.all(files.map(async (fileName) => {
                const imageRes = await axios.get(`http://localhost:8081/api/charts/${fileName}`, {
                    headers: { Authorization: `Bearer ${token}` },
                    responseType: 'blob'
                });
                return URL.createObjectURL(imageRes.data);
            }));

            setChartsData(chartsUrls);

        } catch (err) {
            console.error("Błąd podczas pobierania wykresów:", err);
        }
    };


    useEffect(() => {
        fetchData();
    }, []);

    const handleLogout = () => {
        localStorage.removeItem("token");
        window.location.href = "/login";

        console.log("Wylogowano");
    };

    if (!user) return <div>Ładowanie...</div>;

    return (
        <div className={styles.main_container}>
            <Navbar onLogout={handleLogout} username={user.login} />
            <MainArea
                data={data}
                setData={setData}
                role={user.roles?.[0]?.name || "User"}
                chartsData={chartsData}
                fetchCharts={fetchCharts}
            />
        </div>
    );
};

export default Main;
