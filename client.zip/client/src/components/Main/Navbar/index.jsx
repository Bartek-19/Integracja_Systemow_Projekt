import styles from './styles.module.css';

const Navbar = ({ onLogout, username }) => {
    return (
        <nav className={styles.navbar}>
            <h1>Projekt z przedmiotu: Integracja systemów</h1>
            <div className={styles.userSection}>
                <span className={styles.username}>Zalogowany jako: {username}</span>
                <button className={styles.white_btn} onClick={onLogout}>
                    Wyloguj
                </button>
            </div>
        </nav>
    );
};

export default Navbar;
