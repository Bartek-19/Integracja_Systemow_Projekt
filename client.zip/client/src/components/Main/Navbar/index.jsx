import styles from './styles.module.css';

const Navbar = ({ onLogout }) => {
    return (
        <nav className={styles.navbar}>
            <h1>Projekt z przedmiotu: Integracja systemów</h1>
            <button className={styles.white_btn} onClick={onLogout}>
                Logout
            </button>
        </nav>
    );
};

export default Navbar;