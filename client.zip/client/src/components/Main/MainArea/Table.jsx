import { useState } from "react";
import axios from "axios";
import styles from "./styles.module.css";

const Table = ({ data, setData, role }) => {
    const token = localStorage.getItem("token");
    const [showForm, setShowForm] = useState(false);
    const [newRow, setNewRow] = useState({
        rok: '',
        inflacja: '',
        absolwenci: ''
    });

    const handleEdit = (index, field, value) => {
        const updated = [...data];
        updated[index][field] = value;
        setData(updated);

        axios.put(`http://localhost:8080/api/data/${updated[index].id}`, updated[index], {
            headers: { Authorization: `Bearer ${token}` }
        }).catch(err => console.error("Błąd zapisu:", err));
    };

    const handleDelete = (index) => {
        const id = data[index].id;
        axios.delete(`http://localhost:8080/api/data/${id}`, {
            headers: { Authorization: `Bearer ${token}` }
        }).then(() => {
            const updated = data.filter((_, i) => i !== index);
            setData(updated);
        }).catch(err => console.error("Błąd usuwania:", err));
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setNewRow(prev => ({ ...prev, [name]: value }));
    };

    const handleAddRow = () => {
        const { rok, inflacja, absolwenci } = newRow;
        if (!rok || !inflacja || !absolwenci) {
            alert("Wszystkie pola muszą być wypełnione.");
            return;
        }

        axios.post("http://localhost:8080/api/data", newRow, {
            headers: { Authorization: `Bearer ${token}` }
        }).then(res => {
            setData([...data, res.data]);
            setNewRow({ rok: '', inflacja: '', absolwenci: '' });
            setShowForm(false);
        }).catch(err => console.error("Błąd dodawania:", err));
    };

    return (
        <div>
            <table className={styles.table}>
                <thead>
                    <tr>
                        <th>Rok</th>
                        <th>Inflacja (%)</th>
                        <th>Absolwenci</th>
                        {role === 'Admin' && <th>Akcje</th>}
                    </tr>
                </thead>
                <tbody>
                    {data.map((row, i) => (
                        <tr key={row.id || i}>
                            <td
                                contentEditable={role === 'Admin'}
                                suppressContentEditableWarning
                                onBlur={(e) => handleEdit(i, 'rok', e.target.textContent)}
                            >{row.rok}</td>
                            <td
                                contentEditable={role === 'Admin'}
                                suppressContentEditableWarning
                                onBlur={(e) => handleEdit(i, 'inflacja', e.target.textContent)}
                            >{row.inflacja}</td>
                            <td
                                contentEditable={role === 'Admin'}
                                suppressContentEditableWarning
                                onBlur={(e) => handleEdit(i, 'absolwenci', e.target.textContent)}
                            >{row.absolwenci}</td>
                            {role === 'Admin' && (
                                <td>
                                    <button className={styles.deleteBtn} onClick={() => handleDelete(i)}>
                                        Usuń
                                    </button>
                                </td>
                            )}
                        </tr>
                    ))}
                </tbody>
            </table>

            {role === 'Admin' && (
                <>
                    <div className={styles.actions}>
                        <button
                            id="add-row-toggle"
                            className={`${styles.button} ${styles.cancelBtn}`}
                            onClick={() => setShowForm(!showForm)}
                        >
                            {showForm ? "Anuluj" : "Dodaj wiersz"}
                        </button>
                    </div>

                    {showForm && (
                        <div className={styles.form}>
                            <input
                                type="number"
                                name="rok"
                                placeholder="Rok"
                                value={newRow.rok}
                                onChange={handleInputChange}
                            />
                            <input
                                type="number"
                                step="0.01"
                                name="inflacja"
                                placeholder="Inflacja (%)"
                                value={newRow.inflacja}
                                onChange={handleInputChange}
                            />
                            <input
                                type="number"
                                name="absolwenci"
                                placeholder="Liczba absolwentów"
                                value={newRow.absolwenci}
                                onChange={handleInputChange}
                            />
                            <button className={styles.button} onClick={handleAddRow}>Zapisz</button>
                        </div>
                    )}
                </>
            )}
        </div>
    );
};

export default Table;
