import { useState } from "react";
import axios from "axios";
import styles from "./styles.module.css";

const Table = ({ data, setData, role }) => {
    const token = localStorage.getItem("token");
    const [showForm, setShowForm] = useState(false);
    const [newRow, setNewRow] = useState({
        rok: '',
        inflacja: '',
        absolwenci: ''
    });

    const handleEdit = async (index, field, value) => {
        const updated = [...data];
        updated[index][field] = field === 'inflacja' || field === 'absolwenci' ? Number(value) : value;
        setData(updated);

        const row = updated[index];

        try {
            if (field === 'inflacja') {
                await axios.post("http://localhost:8080/api/inflations", {
                    year: row.rok,
                    rate: parseFloat(row.inflacja)
                }, { headers: { Authorization: `Bearer ${token}` } });
            } else if (field === 'absolwenci') {
                await axios.post("http://localhost:8080/api/graduates", {
                    year: row.rok,
                    count: parseInt(row.absolwenci)
                }, { headers: { Authorization: `Bearer ${token}` } });
            }
        } catch (err) {
            console.error("Błąd zapisu:", err);
        }
    };

    const handleDelete = async (index) => {
        const year = data[index].rok;

        try {
            await Promise.all([
                axios.delete(`http://localhost:8080/api/inflations/${year}`, {
                    headers: { Authorization: `Bearer ${token}` }
                }),
                axios.delete(`http://localhost:8080/api/graduates/${year}`, {
                    headers: { Authorization: `Bearer ${token}` }
                })
            ]);

            const updated = data.filter((_, i) => i !== index);
            setData(updated);
        } catch (err) {
            console.error("Błąd usuwania:", err);
        }
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setNewRow(prev => ({ ...prev, [name]: value }));
    };

    const handleAddRow = async () => {
        const { rok, inflacja, absolwenci } = newRow;
        if (!rok || !inflacja || !absolwenci) {
            alert("Wszystkie pola muszą być wypełnione.");
            return;
        }

        try {
            // równoległe zapisy do obu tabel
            const [infRes, gradRes] = await Promise.all([
                axios.post("http://localhost:8080/api/inflations", {
                    year: parseInt(rok),
                    rate: parseFloat(inflacja)
                }, { headers: { Authorization: `Bearer ${token}` } }),

                axios.post("http://localhost:8080/api/graduates", {
                    year: parseInt(rok),
                    count: parseInt(absolwenci)
                }, { headers: { Authorization: `Bearer ${token}` } })
            ]);

            setData([...data, {
                id: parseInt(rok),
                rok: parseInt(rok),
                inflacja: parseFloat(inflacja),
                absolwenci: parseInt(absolwenci)
            }]);

            setNewRow({ rok: '', inflacja: '', absolwenci: '' });
            setShowForm(false);
        } catch (err) {
            console.error("Błąd dodawania:", err);
            alert("Nie udało się dodać danych.");
        }
    };

    return (
        <div>
            <table className={styles.table}>
                <thead>
                    <tr>
                        <th>Rok</th>
                        <th>Inflacja (%)</th>
                        <th>Absolwenci</th>
                        {role === 'Admin' && <th>Akcje</th>}
                    </tr>
                </thead>
                <tbody>
                    {data.map((row, i) => (
                        <tr key={row.id || i}>
                            <td
                                contentEditable={role === 'Admin'}
                                suppressContentEditableWarning
                                onBlur={(e) => handleEdit(i, 'rok', e.target.textContent)}
                            >{row.rok}</td>
                            <td
                                contentEditable={role === 'Admin'}
                                suppressContentEditableWarning
                                onBlur={(e) => handleEdit(i, 'inflacja', e.target.textContent)}
                            >{row.inflacja}</td>
                            <td
                                contentEditable={role === 'Admin'}
                                suppressContentEditableWarning
                                onBlur={(e) => handleEdit(i, 'absolwenci', e.target.textContent)}
                            >{row.absolwenci}</td>
                            {role === 'Admin' && (
                                <td>
                                    <button className={styles.deleteBtn} onClick={() => handleDelete(i)}>
                                        Usuń
                                    </button>
                                </td>
                            )}
                        </tr>
                    ))}
                </tbody>
            </table>

            {role === 'Admin' && (
                <>
                    <div className={styles.actions}>
                        <button
                            id="add-row-toggle"
                            className={`${styles.button} ${styles.cancelBtn}`}
                            onClick={() => setShowForm(!showForm)}
                        >
                            {showForm ? "Anuluj" : "Dodaj wiersz"}
                        </button>
                    </div>

                    {showForm && (
                        <div className={styles.form}>
                            <input
                                type="number"
                                name="rok"
                                placeholder="Rok"
                                value={newRow.rok}
                                onChange={handleInputChange}
                            />
                            <input
                                type="number"
                                step="0.01"
                                name="inflacja"
                                placeholder="Inflacja (%)"
                                value={newRow.inflacja}
                                onChange={handleInputChange}
                            />
                            <input
                                type="number"
                                name="absolwenci"
                                placeholder="Liczba absolwentów"
                                value={newRow.absolwenci}
                                onChange={handleInputChange}
                            />
                            <button className={styles.button} onClick={handleAddRow}>Zapisz</button>
                        </div>
                    )}
                </>
            )}
        </div>
    );
};

export default Table;
