import { useState } from "react";
import Table from './Table';
import Charts from './Charts';
import styles from './styles.module.css';

const MainArea = ({ data, setData, role, chartsData, fetchCharts }) => {
  const [showCharts, setShowCharts] = useState(false);

  const toggleCharts = async () => {
    if (!showCharts) {
      await fetchCharts(); // pobierz wykresy tylko przy pokazaniu
    }
    setShowCharts(!showCharts);
  };

  return (
    <div className={styles.main_area}>
      <h2 className={styles.heading}>
        Tabela opisująca zależność między inflacją a liczbą absolwentów szkół wyższych w Polsce
      </h2>
      <Table data={data} setData={setData} role={role} />
      <div className={styles.actions}>
        <button
          className={`${styles.button} ${styles.showChartsButton}`}
          onClick={toggleCharts}
        >
          {showCharts ? "Schowaj wykresy" : "Pokaż wykresy"}
        </button>
      </div>
      {showCharts && <Charts data={chartsData} />}
    </div>
  );
};

export default MainArea;
