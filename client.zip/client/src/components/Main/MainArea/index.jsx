import Table from './Table';
import Charts from './Charts';
import styles from './styles.module.css';

const MainArea = ({ data, setData, role, chartsData, fetchCharts }) => {
    return (
        <div className={styles.main_area}>
            <h2 className={styles.heading}>Tabela opisująca zależność między inflacją a liczbą absolwentów szkół wyższych w Polsce</h2>
            <Table data={data} setData={setData} role={role} />
            <div className={styles.actions}>
                <button
                    className={`${styles.button} ${styles.showChartsButton}`}
                    onClick={fetchCharts}
                >Pokaż wykresy</button>
            </div>
            {chartsData && <Charts data={chartsData} />}
        </div>
    );
};

export default MainArea;
