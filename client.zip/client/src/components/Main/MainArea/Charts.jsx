import styles from './styles.module.css';

const Charts = ({ data }) => {
  if (!data || !data.length) return null;

  return (
    <div className={styles.charts_container}>
      {data.map((src, index) => (
        <div key={index} className={styles.chart_wrapper}>
          <img src={src} alt={`Wykres ${index + 1}`} className={styles.chart_image} />
        </div>
      ))}
    </div>
  );
};

export default Charts;
