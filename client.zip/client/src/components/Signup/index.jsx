import { useState } from "react"
import axios from "axios"
import { Link, useNavigate } from "react-router-dom"
import styles from "./styles.module.css"

const Signup = () => {
    const [data, setData] = useState({
        login: "",
        password: "",
    })
    const [error, setError] = useState("")
    const [success, setSuccess] = useState("");
    const navigate = useNavigate()
    const handleChange = ({ currentTarget: input }) => {
        setData({ ...data, [input.name]: input.value })
    }
    const handleSubmit = async (e) => {
        e.preventDefault()
        setError("");
        setSuccess("");

        try {
            const url = "http://localhost:8080/api/users"
            const { data: res } = await axios.post(url, data)

            setSuccess("Użytkownik został pomyślnie zarejestrowany.");
            setTimeout(() => navigate("/login"), 1500);

            console.log(res.message)
        } catch (error) {
            if (
                error.response &&
                error.response.status >= 400 &&
                error.response.status <= 500
            ) {
                const message = typeof error.response.data === "string"
                    ? error.response.data
                    : error.response.data.message;

                setError(message || "Wystąpił błąd rejestracji.");
            } else {
                setError("Błąd sieci. Spróbuj ponownie.");
            }
        }
    }
    return (
        <div className={styles.signup_container}>
            <div className={styles.signup_form_container}>
                <div className={styles.left}>
                    <h1>Witaj ponownie</h1>
                    <Link to="/login">
                        <button type="button"
                            className={styles.white_btn}>
                            Zaloguj się
                        </button>
                    </Link>
                </div>
                <div className={styles.right}>
                    <form className={styles.form_container} onSubmit={handleSubmit}>
                        <h1>Stwórz konto</h1>
                        <input
                            type="text"
                            placeholder="Login"
                            name="login"
                            onChange={handleChange}
                            value={data.login}
                            required
                            className={styles.input}
                        />
                        <input
                            type="password"
                            placeholder="Hasło"
                            name="password"
                            onChange={handleChange}
                            value={data.password}
                            required
                            className={styles.input}
                        />
                        {error && <div className={styles.error_msg}>{error}</div>}
                        {success && <div className={styles.success_msg}>{success}</div>}

                        <button type="submit"
                            className={styles.green_btn}>
                            Zarejestruj się
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default Signup