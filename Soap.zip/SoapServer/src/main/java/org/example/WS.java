package org.example;

import javax.jws.WebService;

@WebService(endpointInterface = "org.example.SOAPInterface")
public class WS implements SOAPInterface {

    private String cachedXmlData;

    public WS() {
        initializeData();
    }

    private void initializeData() {
        DataFromApi dataFetcher = new DataFromApi();
        String filteredJson = dataFetcher.fetchDataAndConvertToFilteredJson();

        if (filteredJson != null) {
            this.cachedXmlData = dataFetcher.convertJsonToXml(filteredJson);
            System.out.println("Dane z API GUS zostały pomyślnie załadowane i skonwertowane do XML.");
        } else {
            System.err.println("Nie udało się pobrać i przetworzyć danych z API GUS. Serwis będzie zwracał domyślny komunikat o błędzie.");
            this.cachedXmlData = "<data><error>Nie udało się załadować danych z API GUS.</error></data>";
        }
    }
    @Override
    public String getData() {
        return cachedXmlData;
    }
}