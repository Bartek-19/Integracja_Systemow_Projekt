package org.example;

public class Main {
    public static void main(String[] args) {
        Publisher publisher = new Publisher();
        publisher.start();
    }
}